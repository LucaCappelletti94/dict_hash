"""Current version of package dict_hash"""
__version__ = "1.1.28"
